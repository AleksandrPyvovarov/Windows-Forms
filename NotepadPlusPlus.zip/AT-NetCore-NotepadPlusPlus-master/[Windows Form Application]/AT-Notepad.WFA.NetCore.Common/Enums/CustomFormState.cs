﻿namespace AT_Notepad.WFA.NetCore.Common.Enums
{
    public enum CustomFormState : sbyte
    {
        Normal = 1,

        Maximize = 2
    }
}
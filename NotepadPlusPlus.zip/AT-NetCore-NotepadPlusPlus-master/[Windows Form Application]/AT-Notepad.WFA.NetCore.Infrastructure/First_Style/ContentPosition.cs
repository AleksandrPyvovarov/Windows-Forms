﻿namespace AT_Notepad.WFA.NetCore.Infrastructure.First_Style
{
    public class ContentPosition
    {
        public int LineIndex;
        public int ColumnIndex;
    }
}
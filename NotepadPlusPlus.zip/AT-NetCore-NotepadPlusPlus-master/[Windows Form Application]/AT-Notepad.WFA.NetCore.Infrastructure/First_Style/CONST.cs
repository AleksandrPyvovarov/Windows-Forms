﻿namespace AT_Notepad.WFA.NetCore.Infrastructure.First_Style
{
    public static class CONST
    {
        public const string CannotFindMessage = "Cannot find \"{SearchText}\"";
    }
}